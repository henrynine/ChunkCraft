# cs3110-a6
For optimal appearance, use terminal settings to convert the following colors
because of lack of choice in ANSITerminal colors:

yellow -> brown
