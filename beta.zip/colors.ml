open ANSITerminal

let brown = ANSITerminal.yellow
let on_brown = ANSITerminal.on_yellow

let gray = ANSITerminal.cyan
let on_gray = ANSITerminal.on_cyan

let pink = ANSITerminal.magenta
let on_pink = ANSITerminal.on_magenta

let orange = ANSITerminal.red
let on_orange = ANSITerminal.on_red
