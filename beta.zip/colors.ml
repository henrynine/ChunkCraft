open ANSITerminal

let brown = ANSITerminal.yellow
let on_brown = ANSITerminal.on_yellow
